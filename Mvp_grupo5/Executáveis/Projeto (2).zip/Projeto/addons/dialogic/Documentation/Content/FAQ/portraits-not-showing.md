# Show portraits?

**Portraits not showing in game?**
In order to make the characters show up on the screen, you need to make them join your current scene using the [Character Join](../Events/001.md). 

If you used the join event and still don't see them, you should try modifying the offset and scale values in your character's portrait until they do appear.